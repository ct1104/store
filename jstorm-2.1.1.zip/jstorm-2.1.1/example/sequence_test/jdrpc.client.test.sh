#!/bin/bash

jstorm jar sequence-split-merge.jar  com.alipay.dw.jstorm.example.drpc.TestReachTopology localhost
