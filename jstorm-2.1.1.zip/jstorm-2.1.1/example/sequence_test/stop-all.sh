#!/bin/bash

jstorm kill SequenceTest 1
jstorm kill Batch 1
jstorm kill TridentWordCount 1
jstorm kill reach 1
